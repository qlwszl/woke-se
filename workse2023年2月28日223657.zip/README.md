解压  workse.zip，安装JDK 下载路径 https://www.oracle.com/

